-- SELECT TOP(500) * FROM [webstore].[dbo].[Products];

-- INSERT DATA
-- INSERT INTO [webstore].[dbo].[Products] (name) VALUES('product2');

-- GET THE LAST INSERT ID
-- SELECT SCOPE_IDENTITY()

SELECT COUNT(*) FROM webstore.dbo.Products;

 -- CREATE DATABASE webstore;

 SELECT USER_NAME();

